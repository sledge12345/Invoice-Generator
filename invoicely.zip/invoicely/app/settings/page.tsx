'use client';
import { useState } from 'react';
import { Save, User, Building2, Mail, MapPin } from 'lucide-react';

export default function SettingsPage() {
  const [form, setForm] = useState({
    name: 'Alex Rivera',
    company: 'Rivera Creative',
    email: 'alex@freelance.io',
    address: '100 Maker St, Portland, OR 97201',
    defaultTax: '0',
    defaultDueDays: '30',
    defaultNotes: 'Thank you for your business! Payment is due within the specified timeframe.',
  });
  const [saved, setSaved] = useState(false);

  function handleSave() {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  const inputCls = 'w-full px-3.5 py-2.5 bg-white border border-ink-200 rounded-xl text-sm text-ink-800 placeholder:text-ink-300 focus:outline-none focus:ring-2 focus:ring-sage-300 focus:border-transparent transition';
  const labelCls = 'block text-xs font-semibold text-ink-500 uppercase tracking-wider mb-1.5';

  return (
    <div className="p-8 animate-fadeIn max-w-2xl">
      <div className="flex items-start justify-between mb-8">
        <div>
          <h1 className="font-display text-3xl text-ink-900">Settings</h1>
          <p className="text-ink-400 mt-1 text-sm">Manage your freelance profile and defaults.</p>
        </div>
        <button
          onClick={handleSave}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all shadow-sm ${
            saved ? 'bg-sage-500 text-white' : 'bg-ink-900 hover:bg-ink-700 text-cream'
          }`}
        >
          <Save size={14} />
          {saved ? 'Saved!' : 'Save Changes'}
        </button>
      </div>

      <div className="space-y-6">
        {/* Profile */}
        <div className="bg-white rounded-2xl shadow-card border border-ink-100 p-6">
          <h2 className="font-semibold text-ink-800 mb-4 flex items-center gap-2">
            <User size={16} className="text-sage-500" /> Your Profile
          </h2>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className={labelCls}>Full Name</label>
              <input className={inputCls} value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
            </div>
            <div>
              <label className={labelCls}>Company / Business Name</label>
              <input className={inputCls} value={form.company} onChange={e => setForm(f => ({ ...f, company: e.target.value }))} />
            </div>
            <div>
              <label className={labelCls}>Email</label>
              <input className={inputCls} type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
            </div>
            <div>
              <label className={labelCls}>Address</label>
              <input className={inputCls} value={form.address} onChange={e => setForm(f => ({ ...f, address: e.target.value }))} />
            </div>
          </div>
        </div>

        {/* Defaults */}
        <div className="bg-white rounded-2xl shadow-card border border-ink-100 p-6">
          <h2 className="font-semibold text-ink-800 mb-4 flex items-center gap-2">
            <Building2 size={16} className="text-sage-500" /> Invoice Defaults
          </h2>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className={labelCls}>Default Tax Rate (%)</label>
              <input className={inputCls + ' font-mono'} type="number" min="0" max="100" step="0.01" value={form.defaultTax} onChange={e => setForm(f => ({ ...f, defaultTax: e.target.value }))} />
            </div>
            <div>
              <label className={labelCls}>Payment Terms (Days)</label>
              <input className={inputCls + ' font-mono'} type="number" min="1" value={form.defaultDueDays} onChange={e => setForm(f => ({ ...f, defaultDueDays: e.target.value }))} />
            </div>
          </div>
          <div className="mt-4">
            <label className={labelCls}>Default Invoice Notes</label>
            <textarea
              className={inputCls + ' resize-none h-20'}
              value={form.defaultNotes}
              onChange={e => setForm(f => ({ ...f, defaultNotes: e.target.value }))}
            />
          </div>
        </div>

        {/* Danger */}
        <div className="bg-white rounded-2xl shadow-card border border-red-100 p-6">
          <h2 className="font-semibold text-red-700 mb-2 text-sm">Danger Zone</h2>
          <p className="text-ink-400 text-xs mb-3">This will permanently delete all invoices and clients from local storage.</p>
          <button
            onClick={() => {
              if (confirm('Delete ALL data? This cannot be undone.')) {
                localStorage.clear();
                window.location.reload();
              }
            }}
            className="px-4 py-2 text-sm font-semibold text-red-600 border border-red-200 rounded-xl hover:bg-red-50 transition-colors"
          >
            Clear All Data
          </button>
        </div>
      </div>
    </div>
  );
}
