'use client';
import { useEffect, useState } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { UserPlus, Trash2, Mail, Phone, Building2, X } from 'lucide-react';
import { getClients, saveClient, deleteClient, getInvoices } from '@/lib/storage';
import { Client, Invoice } from '@/lib/types';

export default function ClientsPage() {
  const [clients, setClients] = useState<Client[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', company: '', address: '', phone: '' });

  useEffect(() => {
    setClients(getClients());
    setInvoices(getInvoices());
  }, []);

  function handleSave() {
    if (!form.name || !form.email) return alert('Name and email are required.');
    const client: Client = { id: uuidv4(), ...form, createdAt: new Date().toISOString() };
    saveClient(client);
    setClients(getClients());
    setShowModal(false);
    setForm({ name: '', email: '', company: '', address: '', phone: '' });
  }

  function handleDelete(id: string) {
    if (!confirm('Delete this client?')) return;
    deleteClient(id);
    setClients(getClients());
  }

  function clientInvoiceCount(id: string) {
    return invoices.filter(i => i.clientId === id).length;
  }

  const inputCls = 'w-full px-3.5 py-2.5 bg-ink-50 border border-ink-200 rounded-xl text-sm text-ink-800 placeholder:text-ink-300 focus:outline-none focus:ring-2 focus:ring-sage-300 focus:border-transparent transition';
  const labelCls = 'block text-xs font-semibold text-ink-500 uppercase tracking-wider mb-1.5';

  return (
    <div className="p-8 animate-fadeIn">
      <div className="flex items-start justify-between mb-8">
        <div>
          <h1 className="font-display text-3xl text-ink-900">Clients</h1>
          <p className="text-ink-400 mt-1 text-sm">{clients.length} clients total</p>
        </div>
        <button
          onClick={() => setShowModal(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-ink-900 hover:bg-ink-700 text-cream rounded-xl text-sm font-semibold transition-all shadow-sm"
        >
          <UserPlus size={15} /> Add Client
        </button>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-3 gap-4">
        {clients.length === 0 && (
          <div className="col-span-3 py-20 text-center text-ink-400 text-sm bg-white rounded-2xl border border-ink-100">
            No clients yet. Add your first client to get started.
          </div>
        )}
        {clients.map(client => (
          <div key={client.id} className="bg-white rounded-2xl shadow-card border border-ink-100 p-5 hover:shadow-card-hover transition-shadow duration-200 group">
            <div className="flex items-start justify-between mb-3">
              <div className="w-10 h-10 rounded-xl bg-ink-900 flex items-center justify-center text-cream font-bold text-sm">
                {client.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}
              </div>
              <button
                onClick={() => handleDelete(client.id)}
                className="opacity-0 group-hover:opacity-100 p-1.5 rounded-lg hover:bg-red-50 text-ink-300 hover:text-red-500 transition-all"
              >
                <Trash2 size={13} />
              </button>
            </div>
            <h3 className="font-semibold text-ink-900 text-sm">{client.name}</h3>
            {client.company && (
              <p className="text-ink-400 text-xs flex items-center gap-1 mt-0.5">
                <Building2 size={10} /> {client.company}
              </p>
            )}
            <div className="mt-3 space-y-1.5">
              <a href={`mailto:${client.email}`} className="flex items-center gap-2 text-xs text-ink-500 hover:text-sage-600 transition-colors">
                <Mail size={11} /> {client.email}
              </a>
              {client.phone && (
                <p className="flex items-center gap-2 text-xs text-ink-500">
                  <Phone size={11} /> {client.phone}
                </p>
              )}
            </div>
            <div className="mt-4 pt-3 border-t border-ink-100 flex items-center justify-between">
              <span className="text-xs text-ink-400">{clientInvoiceCount(client.id)} invoices</span>
              <span className="text-xs text-ink-300">Since {new Date(client.createdAt).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-ink-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-modal w-full max-w-md p-6 animate-fadeIn">
            <div className="flex items-center justify-between mb-6">
              <h2 className="font-display text-2xl text-ink-900">New Client</h2>
              <button onClick={() => setShowModal(false)} className="p-1.5 rounded-lg hover:bg-ink-100 text-ink-400 transition-colors">
                <X size={16} />
              </button>
            </div>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className={labelCls}>Full Name *</label>
                  <input className={inputCls} value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Jane Smith" />
                </div>
                <div>
                  <label className={labelCls}>Company</label>
                  <input className={inputCls} value={form.company} onChange={e => setForm(f => ({ ...f, company: e.target.value }))} placeholder="Acme Corp" />
                </div>
              </div>
              <div>
                <label className={labelCls}>Email *</label>
                <input className={inputCls} type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} placeholder="jane@acme.com" />
              </div>
              <div>
                <label className={labelCls}>Phone</label>
                <input className={inputCls} value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} placeholder="+1 555 000 0000" />
              </div>
              <div>
                <label className={labelCls}>Address</label>
                <input className={inputCls} value={form.address} onChange={e => setForm(f => ({ ...f, address: e.target.value }))} placeholder="123 Main St, City, ST 00000" />
              </div>
            </div>
            <div className="flex gap-2 mt-6">
              <button onClick={() => setShowModal(false)} className="flex-1 py-2.5 rounded-xl border border-ink-200 text-sm font-medium text-ink-500 hover:bg-ink-50 transition-colors">
                Cancel
              </button>
              <button onClick={handleSave} className="flex-1 py-2.5 rounded-xl bg-ink-900 hover:bg-ink-700 text-cream text-sm font-semibold transition-all">
                Add Client
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
