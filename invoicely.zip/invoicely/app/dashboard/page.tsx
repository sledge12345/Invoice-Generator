'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { TrendingUp, Clock, AlertTriangle, CheckCircle, ArrowRight, PlusCircle } from 'lucide-react';
import { getDashboardStats, getInvoices, formatCurrency, calcTotal } from '@/lib/storage';
import { DashboardStats, Invoice } from '@/lib/types';
import StatusBadge from '@/components/StatusBadge';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

const revenueData = [
  { month: 'Sep', revenue: 3200 },
  { month: 'Oct', revenue: 5800 },
  { month: 'Nov', revenue: 4100 },
  { month: 'Dec', revenue: 7600 },
  { month: 'Jan', revenue: 9200 },
  { month: 'Feb', revenue: 6900 },
];

export default function DashboardPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [recent, setRecent] = useState<Invoice[]>([]);

  useEffect(() => {
    setStats(getDashboardStats());
    setRecent(getInvoices().slice(0, 5));
  }, []);

  if (!stats) return null;

  const statCards = [
    {
      label: 'Total Revenue',
      value: formatCurrency(stats.totalRevenue),
      icon: TrendingUp,
      color: 'text-sage-500',
      bg: 'bg-sage-50',
      sub: `${stats.paidInvoices} paid invoices`,
    },
    {
      label: 'Outstanding',
      value: formatCurrency(stats.outstanding),
      icon: Clock,
      color: 'text-blue-500',
      bg: 'bg-blue-50',
      sub: `${stats.sentInvoices} awaiting payment`,
    },
    {
      label: 'Overdue',
      value: formatCurrency(stats.overdue),
      icon: AlertTriangle,
      color: 'text-red-500',
      bg: 'bg-red-50',
      sub: `${stats.overdueInvoices} invoices`,
    },
    {
      label: 'Paid This Month',
      value: formatCurrency(stats.paidThisMonth),
      icon: CheckCircle,
      color: 'text-gold',
      bg: 'bg-amber-50',
      sub: 'Current month',
    },
  ];

  return (
    <div className="p-8 animate-fadeIn">
      {/* Header */}
      <div className="flex items-start justify-between mb-8">
        <div>
          <h1 className="font-display text-3xl text-ink-900">Dashboard</h1>
          <p className="text-ink-400 mt-1 text-sm">Welcome back, Alex. Here's your financial overview.</p>
        </div>
        <Link
          href="/new-invoice"
          className="flex items-center gap-2 px-4 py-2.5 bg-ink-900 hover:bg-ink-700 text-cream rounded-xl text-sm font-semibold transition-all duration-150 shadow-sm"
        >
          <PlusCircle size={15} />
          New Invoice
        </Link>
      </div>

      {/* Stat Cards */}
      <div className="grid grid-cols-4 gap-4 mb-8">
        {statCards.map(({ label, value, icon: Icon, color, bg, sub }) => (
          <div key={label} className="bg-white rounded-2xl p-5 shadow-card border border-ink-100 hover:shadow-card-hover transition-shadow duration-200">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold text-ink-400 uppercase tracking-wider">{label}</span>
              <div className={`${bg} p-2 rounded-lg`}>
                <Icon size={15} className={color} />
              </div>
            </div>
            <p className="text-2xl font-bold text-ink-900 font-display">{value}</p>
            <p className="text-xs text-ink-400 mt-1">{sub}</p>
          </div>
        ))}
      </div>

      {/* Chart + Recent */}
      <div className="grid grid-cols-3 gap-6">
        {/* Revenue Chart */}
        <div className="col-span-2 bg-white rounded-2xl p-6 shadow-card border border-ink-100">
          <div className="flex items-center justify-between mb-6">
            <h2 className="font-semibold text-ink-800">Revenue Overview</h2>
            <span className="text-xs text-ink-400 font-mono">Last 6 months</span>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={revenueData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="revenueGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3D6B4F" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#3D6B4F" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#A8A7A2' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: '#A8A7A2' }} axisLine={false} tickLine={false} tickFormatter={v => `$${(v/1000).toFixed(0)}k`} />
              <Tooltip formatter={(v: number) => [formatCurrency(v), 'Revenue']} contentStyle={{ borderRadius: 8, border: '1px solid #E8E8E6', fontSize: 12 }} />
              <Area type="monotone" dataKey="revenue" stroke="#3D6B4F" strokeWidth={2} fill="url(#revenueGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Quick Stats */}
        <div className="bg-ink-900 rounded-2xl p-6 text-cream">
          <h2 className="font-semibold text-ink-200 mb-5 text-sm">Invoice Summary</h2>
          <div className="space-y-4">
            {[
              { label: 'Total Invoices', val: stats.totalInvoices },
              { label: 'Paid', val: stats.paidInvoices },
              { label: 'Awaiting', val: stats.sentInvoices },
              { label: 'Overdue', val: stats.overdueInvoices },
            ].map(({ label, val }) => (
              <div key={label} className="flex justify-between items-center border-b border-ink-700 pb-3 last:border-0 last:pb-0">
                <span className="text-ink-300 text-sm">{label}</span>
                <span className="font-bold font-mono text-lg">{val}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent Invoices */}
      <div className="mt-6 bg-white rounded-2xl shadow-card border border-ink-100 overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-ink-100">
          <h2 className="font-semibold text-ink-800">Recent Invoices</h2>
          <Link href="/invoices" className="flex items-center gap-1.5 text-sm text-sage-500 hover:text-sage-600 font-medium transition-colors">
            View all <ArrowRight size={14} />
          </Link>
        </div>
        <table className="w-full">
          <thead>
            <tr className="bg-ink-50 text-left">
              {['Invoice', 'Client', 'Amount', 'Due Date', 'Status'].map(h => (
                <th key={h} className="px-6 py-3 text-xs font-semibold text-ink-400 uppercase tracking-wider">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-ink-50">
            {recent.map(inv => (
              <tr key={inv.id} className="hover:bg-ink-50 transition-colors">
                <td className="px-6 py-4">
                  <Link href={`/invoices/${inv.id}`} className="font-mono text-sm font-medium text-ink-700 hover:text-sage-600 transition-colors">
                    {inv.invoiceNumber}
                  </Link>
                </td>
                <td className="px-6 py-4">
                  <p className="text-sm text-ink-800 font-medium">{inv.clientName}</p>
                  <p className="text-xs text-ink-400">{inv.clientCompany}</p>
                </td>
                <td className="px-6 py-4">
                  <span className="text-sm font-semibold text-ink-900">{formatCurrency(calcTotal(inv))}</span>
                </td>
                <td className="px-6 py-4">
                  <span className="text-sm text-ink-500">{new Date(inv.dueDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
                </td>
                <td className="px-6 py-4">
                  <StatusBadge status={inv.status} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
