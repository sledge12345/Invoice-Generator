'use client';
import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { ArrowLeft, Download, Trash2, Edit, CheckCircle, Send } from 'lucide-react';
import { getInvoice, saveInvoice, deleteInvoice, formatCurrency, calcSubtotal, calcTax, calcTotal } from '@/lib/storage';
import { Invoice } from '@/lib/types';
import StatusBadge from '@/components/StatusBadge';
import { generatePDF } from '@/lib/pdf';

export default function InvoiceDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const [inv, setInv] = useState<Invoice | null>(null);

  useEffect(() => {
    const found = getInvoice(id);
    if (!found) router.push('/invoices');
    else setInv(found);
  }, [id]);

  if (!inv) return null;

  function handleMarkPaid() {
    if (!inv) return;
    const updated = { ...inv, status: 'paid' as const, updatedAt: new Date().toISOString() };
    saveInvoice(updated);
    setInv(updated);
  }

  function handleMarkSent() {
    if (!inv) return;
    const updated = { ...inv, status: 'sent' as const, updatedAt: new Date().toISOString() };
    saveInvoice(updated);
    setInv(updated);
  }

  function handleDelete() {
    if (!confirm('Delete this invoice?')) return;
    deleteInvoice(inv!.id);
    router.push('/invoices');
  }

  const subtotal = calcSubtotal(inv);
  const tax = calcTax(inv);
  const total = calcTotal(inv);

  return (
    <div className="p-8 animate-fadeIn">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-4">
          <Link href="/invoices" className="p-2 rounded-xl hover:bg-ink-100 text-ink-400 hover:text-ink-700 transition-colors">
            <ArrowLeft size={18} />
          </Link>
          <div>
            <div className="flex items-center gap-3">
              <h1 className="font-display text-3xl text-ink-900">{inv.invoiceNumber}</h1>
              <StatusBadge status={inv.status} />
            </div>
            <p className="text-ink-400 text-sm mt-0.5">
              Issued {new Date(inv.issueDate).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {inv.status === 'draft' && (
            <button onClick={handleMarkSent} className="flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-semibold transition-all">
              <Send size={14} /> Mark as Sent
            </button>
          )}
          {inv.status !== 'paid' && (
            <button onClick={handleMarkPaid} className="flex items-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-sm font-semibold transition-all">
              <CheckCircle size={14} /> Mark as Paid
            </button>
          )}
          <button onClick={() => generatePDF(inv)} className="flex items-center gap-2 px-4 py-2.5 bg-ink-900 hover:bg-ink-700 text-cream rounded-xl text-sm font-semibold transition-all">
            <Download size={14} /> Download PDF
          </button>
          <Link href={`/invoices/${inv.id}/edit`} className="flex items-center gap-2 px-4 py-2.5 bg-white border border-ink-200 hover:bg-ink-50 text-ink-700 rounded-xl text-sm font-semibold transition-all">
            <Edit size={14} /> Edit
          </Link>
          <button onClick={handleDelete} className="p-2.5 rounded-xl border border-red-200 bg-red-50 hover:bg-red-100 text-red-500 transition-all">
            <Trash2 size={15} />
          </button>
        </div>
      </div>

      {/* Invoice Card */}
      <div className="bg-white rounded-2xl shadow-card border border-ink-100 overflow-hidden max-w-4xl">
        {/* Top bar */}
        <div className="bg-ink-900 px-10 py-8 flex justify-between items-start">
          <div>
            <p className="font-display text-2xl text-cream">{inv.fromCompany || inv.fromName}</p>
            <p className="text-ink-300 text-sm mt-1">{inv.fromEmail}</p>
            {inv.fromAddress && <p className="text-ink-400 text-xs mt-0.5">{inv.fromAddress}</p>}
          </div>
          <div className="text-right">
            <p className="text-gold text-xs font-semibold uppercase tracking-widest">Invoice</p>
            <p className="font-mono text-cream text-xl font-bold mt-1">{inv.invoiceNumber}</p>
          </div>
        </div>

        <div className="px-10 py-8">
          {/* From / To / Dates */}
          <div className="grid grid-cols-3 gap-8 mb-8 pb-8 border-b border-ink-100">
            <div>
              <p className="text-xs font-semibold text-ink-400 uppercase tracking-wider mb-2">Bill To</p>
              <p className="font-semibold text-ink-800">{inv.clientName}</p>
              {inv.clientCompany && <p className="text-ink-500 text-sm">{inv.clientCompany}</p>}
              <p className="text-ink-500 text-sm">{inv.clientEmail}</p>
              {inv.clientAddress && <p className="text-ink-400 text-xs mt-1">{inv.clientAddress}</p>}
            </div>
            <div>
              <p className="text-xs font-semibold text-ink-400 uppercase tracking-wider mb-2">Issue Date</p>
              <p className="font-medium text-ink-800">{new Date(inv.issueDate).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</p>
            </div>
            <div>
              <p className="text-xs font-semibold text-ink-400 uppercase tracking-wider mb-2">Due Date</p>
              <p className="font-medium text-ink-800">{new Date(inv.dueDate).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</p>
            </div>
          </div>

          {/* Line Items */}
          <table className="w-full mb-6">
            <thead>
              <tr className="border-b-2 border-ink-100">
                <th className="text-left text-xs font-semibold text-ink-400 uppercase tracking-wider pb-3">Description</th>
                <th className="text-center text-xs font-semibold text-ink-400 uppercase tracking-wider pb-3">Qty</th>
                <th className="text-right text-xs font-semibold text-ink-400 uppercase tracking-wider pb-3">Rate</th>
                <th className="text-right text-xs font-semibold text-ink-400 uppercase tracking-wider pb-3">Amount</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ink-50">
              {inv.lineItems.map(item => (
                <tr key={item.id}>
                  <td className="py-4 text-sm text-ink-800">{item.description}</td>
                  <td className="py-4 text-sm text-ink-500 text-center">{item.quantity}</td>
                  <td className="py-4 text-sm text-ink-500 text-right font-mono">{formatCurrency(item.rate)}</td>
                  <td className="py-4 text-sm font-semibold text-ink-800 text-right font-mono">{formatCurrency(item.quantity * item.rate)}</td>
                </tr>
              ))}
            </tbody>
          </table>

          {/* Totals */}
          <div className="flex justify-end">
            <div className="w-64 space-y-2">
              <div className="flex justify-between text-sm text-ink-500">
                <span>Subtotal</span>
                <span className="font-mono">{formatCurrency(subtotal)}</span>
              </div>
              {inv.taxRate > 0 && (
                <div className="flex justify-between text-sm text-ink-500">
                  <span>Tax ({inv.taxRate}%)</span>
                  <span className="font-mono">{formatCurrency(tax)}</span>
                </div>
              )}
              <div className="flex justify-between text-base font-bold text-ink-900 border-t border-ink-200 pt-2">
                <span>Total</span>
                <span className="font-mono text-sage-600">{formatCurrency(total)}</span>
              </div>
            </div>
          </div>

          {/* Notes */}
          {inv.notes && (
            <div className="mt-8 pt-6 border-t border-ink-100">
              <p className="text-xs font-semibold text-ink-400 uppercase tracking-wider mb-2">Notes</p>
              <p className="text-sm text-ink-600">{inv.notes}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
