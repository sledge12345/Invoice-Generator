'use client';
import { useParams } from 'next/navigation';
import InvoiceForm from '@/components/InvoiceForm';
import AppLayout from '@/app/dashboard/layout';

export default function EditInvoicePage() {
  const { id } = useParams<{ id: string }>();
  return <InvoiceForm editId={id} />;
}
