'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { PlusCircle, Search, Trash2, Download, Eye } from 'lucide-react';
import { getInvoices, deleteInvoice, formatCurrency, calcTotal, saveInvoice } from '@/lib/storage';
import { Invoice, InvoiceStatus } from '@/lib/types';
import StatusBadge from '@/components/StatusBadge';
import { generatePDF } from '@/lib/pdf';

const STATUSES: { label: string; value: InvoiceStatus | 'all' }[] = [
  { label: 'All', value: 'all' },
  { label: 'Draft', value: 'draft' },
  { label: 'Sent', value: 'sent' },
  { label: 'Paid', value: 'paid' },
  { label: 'Overdue', value: 'overdue' },
];

export default function InvoicesPage() {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [filter, setFilter] = useState<InvoiceStatus | 'all'>('all');
  const [search, setSearch] = useState('');

  useEffect(() => { setInvoices(getInvoices()); }, []);

  const filtered = invoices.filter(inv => {
    const matchStatus = filter === 'all' || inv.status === filter;
    const q = search.toLowerCase();
    const matchSearch = !q || inv.invoiceNumber.toLowerCase().includes(q)
      || inv.clientName.toLowerCase().includes(q)
      || inv.clientCompany?.toLowerCase().includes(q);
    return matchStatus && matchSearch;
  });

  function handleDelete(id: string) {
    if (!confirm('Delete this invoice?')) return;
    deleteInvoice(id);
    setInvoices(getInvoices());
  }

  function handleMarkPaid(inv: Invoice) {
    saveInvoice({ ...inv, status: 'paid', updatedAt: new Date().toISOString() });
    setInvoices(getInvoices());
  }

  return (
    <div className="p-8 animate-fadeIn">
      <div className="flex items-start justify-between mb-8">
        <div>
          <h1 className="font-display text-3xl text-ink-900">Invoices</h1>
          <p className="text-ink-400 mt-1 text-sm">{invoices.length} invoices total</p>
        </div>
        <Link
          href="/new-invoice"
          className="flex items-center gap-2 px-4 py-2.5 bg-ink-900 hover:bg-ink-700 text-cream rounded-xl text-sm font-semibold transition-all duration-150 shadow-sm"
        >
          <PlusCircle size={15} /> New Invoice
        </Link>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-4 mb-6">
        <div className="relative flex-1 max-w-sm">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-400" />
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search invoices..."
            className="w-full pl-9 pr-4 py-2.5 bg-white border border-ink-200 rounded-xl text-sm text-ink-800 placeholder:text-ink-400 focus:outline-none focus:ring-2 focus:ring-sage-300 focus:border-transparent transition"
          />
        </div>
        <div className="flex gap-1 bg-white border border-ink-200 rounded-xl p-1">
          {STATUSES.map(s => (
            <button
              key={s.value}
              onClick={() => setFilter(s.value)}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                filter === s.value ? 'bg-ink-900 text-cream' : 'text-ink-500 hover:text-ink-800'
              }`}
            >
              {s.label}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl shadow-card border border-ink-100 overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="bg-ink-50 text-left">
              {['Invoice #', 'Client', 'Amount', 'Issue Date', 'Due Date', 'Status', ''].map(h => (
                <th key={h} className="px-6 py-3 text-xs font-semibold text-ink-400 uppercase tracking-wider">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-ink-50">
            {filtered.length === 0 && (
              <tr>
                <td colSpan={7} className="px-6 py-12 text-center text-ink-400 text-sm">
                  No invoices found.{' '}
                  <Link href="/new-invoice" className="text-sage-500 hover:underline">Create one →</Link>
                </td>
              </tr>
            )}
            {filtered.map(inv => (
              <tr key={inv.id} className="hover:bg-ink-50 transition-colors group">
                <td className="px-6 py-4">
                  <Link href={`/invoices/${inv.id}`} className="font-mono text-sm font-semibold text-ink-700 hover:text-sage-600 transition-colors">
                    {inv.invoiceNumber}
                  </Link>
                </td>
                <td className="px-6 py-4">
                  <p className="text-sm font-medium text-ink-800">{inv.clientName}</p>
                  <p className="text-xs text-ink-400">{inv.clientCompany}</p>
                </td>
                <td className="px-6 py-4">
                  <span className="text-sm font-bold text-ink-900">{formatCurrency(calcTotal(inv))}</span>
                </td>
                <td className="px-6 py-4 text-sm text-ink-500">
                  {new Date(inv.issueDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                </td>
                <td className="px-6 py-4 text-sm text-ink-500">
                  {new Date(inv.dueDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                </td>
                <td className="px-6 py-4">
                  <StatusBadge status={inv.status} />
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Link href={`/invoices/${inv.id}`} className="p-1.5 rounded-lg hover:bg-ink-100 text-ink-400 hover:text-ink-700 transition-colors" title="View">
                      <Eye size={14} />
                    </Link>
                    <button onClick={() => generatePDF(inv)} className="p-1.5 rounded-lg hover:bg-ink-100 text-ink-400 hover:text-ink-700 transition-colors" title="Download PDF">
                      <Download size={14} />
                    </button>
                    {inv.status !== 'paid' && (
                      <button onClick={() => handleMarkPaid(inv)} className="px-2 py-1 text-xs rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100 transition-colors font-medium">
                        Mark Paid
                      </button>
                    )}
                    <button onClick={() => handleDelete(inv.id)} className="p-1.5 rounded-lg hover:bg-red-50 text-ink-400 hover:text-red-500 transition-colors" title="Delete">
                      <Trash2 size={14} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
