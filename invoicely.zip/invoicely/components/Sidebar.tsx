'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { LayoutDashboard, FileText, Users, PlusCircle, Settings } from 'lucide-react';
import clsx from 'clsx';

const nav = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/invoices', label: 'Invoices', icon: FileText },
  { href: '/clients', label: 'Clients', icon: Users },
];

export default function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="w-60 min-h-screen bg-ink-900 flex flex-col fixed left-0 top-0 z-40">
      {/* Logo */}
      <div className="px-6 py-7 border-b border-ink-700">
        <span className="font-display text-2xl text-cream tracking-tight">Invoicely</span>
        <p className="text-ink-400 text-xs mt-0.5 font-mono">Freelance Manager</p>
      </div>

      {/* New Invoice CTA */}
      <div className="px-4 pt-5">
        <Link
          href="/new-invoice"
          className="flex items-center gap-2.5 w-full px-4 py-2.5 rounded-xl bg-sage-500 hover:bg-sage-400 text-white text-sm font-semibold transition-all duration-150 shadow-sm hover:shadow-md group"
        >
          <PlusCircle size={16} className="group-hover:rotate-90 transition-transform duration-200" />
          New Invoice
        </Link>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-4 pt-6 space-y-1">
        {nav.map(({ href, label, icon: Icon }) => {
          const active = pathname === href || pathname.startsWith(href + '/');
          return (
            <Link
              key={href}
              href={href}
              className={clsx(
                'flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-150',
                active
                  ? 'bg-ink-700 text-cream'
                  : 'text-ink-300 hover:bg-ink-800 hover:text-cream'
              )}
            >
              <Icon size={16} />
              {label}
            </Link>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="px-4 pb-6">
        <Link
          href="/settings"
          className="flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium text-ink-400 hover:bg-ink-800 hover:text-cream transition-all duration-150"
        >
          <Settings size={16} />
          Settings
        </Link>
        <div className="mt-4 px-4 py-3 rounded-xl bg-ink-800 border border-ink-700">
          <p className="text-xs text-ink-300 font-medium">Alex Rivera</p>
          <p className="text-xs text-ink-500 truncate">alex@freelance.io</p>
        </div>
      </div>
    </aside>
  );
}
