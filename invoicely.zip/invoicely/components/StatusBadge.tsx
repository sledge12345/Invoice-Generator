import clsx from 'clsx';
import { InvoiceStatus } from '@/lib/types';

const labels: Record<InvoiceStatus, string> = {
  draft: 'Draft',
  sent: 'Sent',
  paid: 'Paid',
  overdue: 'Overdue',
};

const styles: Record<InvoiceStatus, string> = {
  draft: 'bg-ink-100 text-ink-500 border-ink-200',
  sent: 'bg-blue-50 text-blue-700 border-blue-200',
  paid: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  overdue: 'bg-red-50 text-red-700 border-red-200',
};

export default function StatusBadge({ status }: { status: InvoiceStatus }) {
  return (
    <span className={clsx(
      'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border',
      styles[status]
    )}>
      {labels[status]}
    </span>
  );
}
