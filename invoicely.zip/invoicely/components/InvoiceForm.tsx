'use client';
import { useEffect, useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import Link from 'next/link';
import { v4 as uuidv4 } from 'uuid';
import { ArrowLeft, Plus, Trash2, Save, Send } from 'lucide-react';
import { getInvoice, getClients, saveInvoice, generateInvoiceNumber, formatCurrency, calcSubtotal, calcTax, calcTotal } from '@/lib/storage';
import { Invoice, LineItem, Client } from '@/lib/types';

interface FormState {
  invoiceNumber: string;
  clientId: string;
  clientName: string;
  clientEmail: string;
  clientCompany: string;
  clientAddress: string;
  issueDate: string;
  dueDate: string;
  taxRate: string;
  notes: string;
  fromName: string;
  fromEmail: string;
  fromCompany: string;
  fromAddress: string;
  lineItems: LineItem[];
}

const defaultForm = (): FormState => ({
  invoiceNumber: generateInvoiceNumber(),
  clientId: '',
  clientName: '',
  clientEmail: '',
  clientCompany: '',
  clientAddress: '',
  issueDate: new Date().toISOString().split('T')[0],
  dueDate: new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0],
  taxRate: '0',
  notes: '',
  fromName: 'Alex Rivera',
  fromEmail: 'alex@freelance.io',
  fromCompany: 'Rivera Creative',
  fromAddress: '100 Maker St, Portland, OR 97201',
  lineItems: [{ id: uuidv4(), description: '', quantity: 1, rate: 0 }],
});

export default function InvoiceForm({ editId }: { editId?: string }) {
  const router = useRouter();
  const [form, setForm] = useState<FormState>(defaultForm());
  const [clients, setClients] = useState<Client[]>([]);
  const [saving, setSaving] = useState(false);
  const isEdit = !!editId;

  useEffect(() => {
    setClients(getClients());
    if (editId) {
      const inv = getInvoice(editId);
      if (inv) {
        setForm({
          invoiceNumber: inv.invoiceNumber,
          clientId: inv.clientId,
          clientName: inv.clientName,
          clientEmail: inv.clientEmail,
          clientCompany: inv.clientCompany || '',
          clientAddress: inv.clientAddress || '',
          issueDate: inv.issueDate,
          dueDate: inv.dueDate,
          taxRate: String(inv.taxRate),
          notes: inv.notes || '',
          fromName: inv.fromName,
          fromEmail: inv.fromEmail,
          fromCompany: inv.fromCompany || '',
          fromAddress: inv.fromAddress || '',
          lineItems: inv.lineItems,
        });
      }
    }
  }, [editId]);

  function selectClient(clientId: string) {
    const c = clients.find(c => c.id === clientId);
    if (!c) return;
    setForm(f => ({ ...f, clientId: c.id, clientName: c.name, clientEmail: c.email, clientCompany: c.company || '', clientAddress: c.address || '' }));
  }

  function updateLineItem(idx: number, field: keyof LineItem, value: string | number) {
    setForm(f => {
      const items = [...f.lineItems];
      items[idx] = { ...items[idx], [field]: value };
      return { ...f, lineItems: items };
    });
  }

  function addLineItem() {
    setForm(f => ({ ...f, lineItems: [...f.lineItems, { id: uuidv4(), description: '', quantity: 1, rate: 0 }] }));
  }

  function removeLineItem(idx: number) {
    setForm(f => ({ ...f, lineItems: f.lineItems.filter((_, i) => i !== idx) }));
  }

  function buildInvoice(status: 'draft' | 'sent'): Invoice {
    const now = new Date().toISOString();
    const existing = editId ? getInvoice(editId) : null;
    return {
      id: existing?.id || uuidv4(),
      invoiceNumber: form.invoiceNumber,
      clientId: form.clientId,
      clientName: form.clientName,
      clientEmail: form.clientEmail,
      clientCompany: form.clientCompany,
      clientAddress: form.clientAddress,
      status,
      issueDate: form.issueDate,
      dueDate: form.dueDate,
      lineItems: form.lineItems,
      taxRate: parseFloat(form.taxRate) || 0,
      notes: form.notes,
      fromName: form.fromName,
      fromEmail: form.fromEmail,
      fromCompany: form.fromCompany,
      fromAddress: form.fromAddress,
      createdAt: existing?.createdAt || now,
      updatedAt: now,
    };
  }

  function handleSave(status: 'draft' | 'sent') {
    setSaving(true);
    const inv = buildInvoice(status);
    saveInvoice(inv);
    router.push(`/invoices/${inv.id}`);
  }

  // Preview totals
  const previewInv = buildInvoice('draft');
  const subtotal = calcSubtotal(previewInv);
  const tax = calcTax(previewInv);
  const total = calcTotal(previewInv);

  const inputCls = 'w-full px-3.5 py-2.5 bg-white border border-ink-200 rounded-xl text-sm text-ink-800 placeholder:text-ink-300 focus:outline-none focus:ring-2 focus:ring-sage-300 focus:border-transparent transition';
  const labelCls = 'block text-xs font-semibold text-ink-500 uppercase tracking-wider mb-1.5';

  return (
    <div className="p-8 animate-fadeIn">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-4">
          <Link href="/invoices" className="p-2 rounded-xl hover:bg-ink-100 text-ink-400 hover:text-ink-700 transition-colors">
            <ArrowLeft size={18} />
          </Link>
          <div>
            <h1 className="font-display text-3xl text-ink-900">{isEdit ? 'Edit Invoice' : 'New Invoice'}</h1>
            <p className="text-ink-400 text-sm mt-0.5 font-mono">{form.invoiceNumber}</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => handleSave('draft')}
            disabled={saving}
            className="flex items-center gap-2 px-4 py-2.5 bg-white border border-ink-200 hover:bg-ink-50 text-ink-700 rounded-xl text-sm font-semibold transition-all"
          >
            <Save size={14} /> Save Draft
          </button>
          <button
            onClick={() => handleSave('sent')}
            disabled={saving}
            className="flex items-center gap-2 px-4 py-2.5 bg-ink-900 hover:bg-ink-700 text-cream rounded-xl text-sm font-semibold transition-all shadow-sm"
          >
            <Send size={14} /> Save & Send
          </button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Main Form */}
        <div className="col-span-2 space-y-6">
          {/* From */}
          <div className="bg-white rounded-2xl shadow-card border border-ink-100 p-6">
            <h2 className="font-semibold text-ink-800 mb-4">Your Details</h2>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className={labelCls}>Your Name</label>
                <input className={inputCls} value={form.fromName} onChange={e => setForm(f => ({ ...f, fromName: e.target.value }))} />
              </div>
              <div>
                <label className={labelCls}>Company</label>
                <input className={inputCls} value={form.fromCompany} onChange={e => setForm(f => ({ ...f, fromCompany: e.target.value }))} />
              </div>
              <div>
                <label className={labelCls}>Email</label>
                <input className={inputCls} type="email" value={form.fromEmail} onChange={e => setForm(f => ({ ...f, fromEmail: e.target.value }))} />
              </div>
              <div>
                <label className={labelCls}>Address</label>
                <input className={inputCls} value={form.fromAddress} onChange={e => setForm(f => ({ ...f, fromAddress: e.target.value }))} />
              </div>
            </div>
          </div>

          {/* Client */}
          <div className="bg-white rounded-2xl shadow-card border border-ink-100 p-6">
            <h2 className="font-semibold text-ink-800 mb-4">Client Details</h2>
            <div className="mb-4">
              <label className={labelCls}>Select Existing Client</label>
              <select className={inputCls} value={form.clientId} onChange={e => selectClient(e.target.value)}>
                <option value="">— Choose a client —</option>
                {clients.map(c => (
                  <option key={c.id} value={c.id}>{c.name}{c.company ? ` (${c.company})` : ''}</option>
                ))}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className={labelCls}>Client Name</label>
                <input className={inputCls} value={form.clientName} onChange={e => setForm(f => ({ ...f, clientName: e.target.value }))} placeholder="Jane Smith" />
              </div>
              <div>
                <label className={labelCls}>Company</label>
                <input className={inputCls} value={form.clientCompany} onChange={e => setForm(f => ({ ...f, clientCompany: e.target.value }))} placeholder="Acme Corp" />
              </div>
              <div>
                <label className={labelCls}>Email</label>
                <input className={inputCls} type="email" value={form.clientEmail} onChange={e => setForm(f => ({ ...f, clientEmail: e.target.value }))} placeholder="jane@acme.com" />
              </div>
              <div>
                <label className={labelCls}>Address</label>
                <input className={inputCls} value={form.clientAddress} onChange={e => setForm(f => ({ ...f, clientAddress: e.target.value }))} placeholder="123 Main St, City" />
              </div>
            </div>
          </div>

          {/* Line Items */}
          <div className="bg-white rounded-2xl shadow-card border border-ink-100 p-6">
            <h2 className="font-semibold text-ink-800 mb-4">Line Items</h2>
            <div className="space-y-3">
              <div className="grid grid-cols-12 gap-3 text-xs font-semibold text-ink-400 uppercase tracking-wider px-1">
                <div className="col-span-6">Description</div>
                <div className="col-span-2 text-center">Qty</div>
                <div className="col-span-3 text-right">Rate</div>
                <div className="col-span-1"></div>
              </div>
              {form.lineItems.map((item, idx) => (
                <div key={item.id} className="grid grid-cols-12 gap-3 items-center">
                  <div className="col-span-6">
                    <input
                      className={inputCls}
                      placeholder="Description of service..."
                      value={item.description}
                      onChange={e => updateLineItem(idx, 'description', e.target.value)}
                    />
                  </div>
                  <div className="col-span-2">
                    <input
                      className={inputCls + ' text-center'}
                      type="number"
                      min="1"
                      value={item.quantity}
                      onChange={e => updateLineItem(idx, 'quantity', parseFloat(e.target.value) || 1)}
                    />
                  </div>
                  <div className="col-span-3">
                    <input
                      className={inputCls + ' text-right font-mono'}
                      type="number"
                      min="0"
                      step="0.01"
                      placeholder="0.00"
                      value={item.rate || ''}
                      onChange={e => updateLineItem(idx, 'rate', parseFloat(e.target.value) || 0)}
                    />
                  </div>
                  <div className="col-span-1 flex justify-center">
                    {form.lineItems.length > 1 && (
                      <button onClick={() => removeLineItem(idx)} className="p-1.5 rounded-lg hover:bg-red-50 text-ink-300 hover:text-red-500 transition-colors">
                        <Trash2 size={14} />
                      </button>
                    )}
                  </div>
                </div>
              ))}
              <button
                onClick={addLineItem}
                className="flex items-center gap-2 text-sm text-sage-600 hover:text-sage-700 font-medium mt-2 transition-colors"
              >
                <Plus size={15} /> Add Line Item
              </button>
            </div>
          </div>

          {/* Notes */}
          <div className="bg-white rounded-2xl shadow-card border border-ink-100 p-6">
            <h2 className="font-semibold text-ink-800 mb-4">Notes</h2>
            <textarea
              className={inputCls + ' resize-none h-24'}
              placeholder="Payment terms, thank you notes, bank details..."
              value={form.notes}
              onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
            />
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          {/* Invoice Meta */}
          <div className="bg-white rounded-2xl shadow-card border border-ink-100 p-5">
            <h2 className="font-semibold text-ink-800 mb-4">Invoice Details</h2>
            <div className="space-y-3">
              <div>
                <label className={labelCls}>Invoice Number</label>
                <input className={inputCls + ' font-mono'} value={form.invoiceNumber} onChange={e => setForm(f => ({ ...f, invoiceNumber: e.target.value }))} />
              </div>
              <div>
                <label className={labelCls}>Issue Date</label>
                <input className={inputCls} type="date" value={form.issueDate} onChange={e => setForm(f => ({ ...f, issueDate: e.target.value }))} />
              </div>
              <div>
                <label className={labelCls}>Due Date</label>
                <input className={inputCls} type="date" value={form.dueDate} onChange={e => setForm(f => ({ ...f, dueDate: e.target.value }))} />
              </div>
              <div>
                <label className={labelCls}>Tax Rate (%)</label>
                <input className={inputCls + ' font-mono'} type="number" min="0" max="100" step="0.01" value={form.taxRate} onChange={e => setForm(f => ({ ...f, taxRate: e.target.value }))} />
              </div>
            </div>
          </div>

          {/* Summary */}
          <div className="bg-ink-900 rounded-2xl p-5 text-cream">
            <h2 className="font-semibold text-ink-200 mb-4 text-sm">Summary</h2>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between text-ink-300">
                <span>Subtotal</span>
                <span className="font-mono">{formatCurrency(subtotal)}</span>
              </div>
              {parseFloat(form.taxRate) > 0 && (
                <div className="flex justify-between text-ink-300">
                  <span>Tax ({form.taxRate}%)</span>
                  <span className="font-mono">{formatCurrency(tax)}</span>
                </div>
              )}
              <div className="flex justify-between font-bold text-base border-t border-ink-700 pt-2 mt-2">
                <span>Total</span>
                <span className="font-mono text-gold">{formatCurrency(total)}</span>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="space-y-2">
            <button
              onClick={() => handleSave('sent')}
              disabled={saving}
              className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-sage-500 hover:bg-sage-600 text-white rounded-xl text-sm font-semibold transition-all shadow-sm"
            >
              <Send size={14} /> Save & Mark Sent
            </button>
            <button
              onClick={() => handleSave('draft')}
              disabled={saving}
              className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-white border border-ink-200 hover:bg-ink-50 text-ink-700 rounded-xl text-sm font-semibold transition-all"
            >
              <Save size={14} /> Save as Draft
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
