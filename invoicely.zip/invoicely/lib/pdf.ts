import { Invoice } from './types';
import { calcSubtotal, calcTax, calcTotal, formatCurrency } from './storage';

export async function generatePDF(invoice: Invoice): Promise<void> {
  const { jsPDF } = await import('jspdf');
  const autoTable = (await import('jspdf-autotable')).default;

  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const pageWidth = doc.internal.pageSize.getWidth();
  const margin = 20;

  // ── Header ──────────────────────────────────────────────────────────────────
  doc.setFillColor(13, 13, 13);
  doc.rect(0, 0, pageWidth, 40, 'F');

  doc.setTextColor(250, 250, 247);
  doc.setFontSize(22);
  doc.setFont('helvetica', 'bold');
  doc.text(invoice.fromCompany || invoice.fromName, margin, 22);

  doc.setFontSize(10);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(196, 147, 63);
  doc.text('INVOICE', pageWidth - margin, 18, { align: 'right' });
  doc.setTextColor(200, 200, 200);
  doc.setFontSize(9);
  doc.text(invoice.invoiceNumber, pageWidth - margin, 26, { align: 'right' });

  // ── From / To ────────────────────────────────────────────────────────────────
  let y = 55;
  doc.setTextColor(13, 13, 13);

  // From
  doc.setFontSize(7);
  doc.setTextColor(120, 120, 120);
  doc.text('FROM', margin, y);
  y += 5;
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(13, 13, 13);
  doc.text(invoice.fromName, margin, y);
  y += 5;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(80, 80, 80);
  doc.text(invoice.fromEmail, margin, y);
  if (invoice.fromAddress) { y += 4; doc.text(invoice.fromAddress, margin, y); }

  // To
  let y2 = 55;
  doc.setFontSize(7);
  doc.setTextColor(120, 120, 120);
  doc.text('BILL TO', pageWidth / 2, y2);
  y2 += 5;
  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(13, 13, 13);
  doc.text(invoice.clientName, pageWidth / 2, y2);
  y2 += 5;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(80, 80, 80);
  if (invoice.clientCompany) { doc.text(invoice.clientCompany, pageWidth / 2, y2); y2 += 4; }
  doc.text(invoice.clientEmail, pageWidth / 2, y2);
  if (invoice.clientAddress) { y2 += 4; doc.text(invoice.clientAddress, pageWidth / 2, y2); }

  // ── Dates ────────────────────────────────────────────────────────────────────
  y = Math.max(y, y2) + 14;
  doc.setDrawColor(220, 220, 220);
  doc.line(margin, y - 5, pageWidth - margin, y - 5);

  doc.setFontSize(8);
  doc.setTextColor(120, 120, 120);
  doc.text('ISSUE DATE', margin, y);
  doc.text('DUE DATE', margin + 60, y);
  doc.text('STATUS', margin + 120, y);
  y += 5;
  doc.setFontSize(10);
  doc.setTextColor(13, 13, 13);
  doc.setFont('helvetica', 'bold');
  doc.text(formatDate(invoice.issueDate), margin, y);
  doc.text(formatDate(invoice.dueDate), margin + 60, y);
  doc.text(invoice.status.toUpperCase(), margin + 120, y);
  doc.setFont('helvetica', 'normal');

  // ── Line Items ────────────────────────────────────────────────────────────────
  y += 12;

  autoTable(doc, {
    startY: y,
    margin: { left: margin, right: margin },
    head: [['Description', 'Qty', 'Rate', 'Amount']],
    body: invoice.lineItems.map(item => [
      item.description,
      item.quantity.toString(),
      formatCurrency(item.rate),
      formatCurrency(item.quantity * item.rate),
    ]),
    headStyles: {
      fillColor: [13, 13, 13],
      textColor: [250, 250, 247],
      fontStyle: 'bold',
      fontSize: 9,
    },
    bodyStyles: { fontSize: 9, textColor: [50, 50, 50] },
    alternateRowStyles: { fillColor: [248, 248, 246] },
    columnStyles: {
      0: { cellWidth: 'auto' },
      1: { cellWidth: 20, halign: 'center' },
      2: { cellWidth: 35, halign: 'right' },
      3: { cellWidth: 35, halign: 'right' },
    },
  });

  // ── Totals ────────────────────────────────────────────────────────────────────
  // @ts-ignore
  const finalY = (doc as any).lastAutoTable.finalY + 8;
  const subtotal = calcSubtotal(invoice);
  const tax = calcTax(invoice);
  const total = calcTotal(invoice);

  const col2 = pageWidth - margin - 40;
  const col1 = col2 - 40;

  doc.setFontSize(9);
  doc.setTextColor(100, 100, 100);
  doc.text('Subtotal', col1, finalY, { align: 'right' });
  doc.text(formatCurrency(subtotal), pageWidth - margin, finalY, { align: 'right' });

  if (invoice.taxRate > 0) {
    doc.text(`Tax (${invoice.taxRate}%)`, col1, finalY + 6, { align: 'right' });
    doc.text(formatCurrency(tax), pageWidth - margin, finalY + 6, { align: 'right' });
  }

  doc.setDrawColor(13, 13, 13);
  doc.line(col1 - 10, finalY + 10, pageWidth - margin, finalY + 10);

  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(13, 13, 13);
  doc.text('TOTAL', col1, finalY + 18, { align: 'right' });
  doc.setTextColor(61, 107, 79);
  doc.text(formatCurrency(total), pageWidth - margin, finalY + 18, { align: 'right' });

  // ── Notes ─────────────────────────────────────────────────────────────────────
  if (invoice.notes) {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(120, 120, 120);
    doc.text('Notes', margin, finalY + 8);
    doc.setTextColor(60, 60, 60);
    doc.text(invoice.notes, margin, finalY + 14);
  }

  // ── Footer ────────────────────────────────────────────────────────────────────
  const pageHeight = doc.internal.pageSize.getHeight();
  doc.setFillColor(13, 13, 13);
  doc.rect(0, pageHeight - 14, pageWidth, 14, 'F');
  doc.setTextColor(150, 150, 150);
  doc.setFontSize(7);
  doc.text('Generated by Invoicely', pageWidth / 2, pageHeight - 5, { align: 'center' });

  doc.save(`${invoice.invoiceNumber}.pdf`);
}

function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString('en-US', {
    year: 'numeric', month: 'long', day: 'numeric',
  });
}
