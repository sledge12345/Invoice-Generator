import { Invoice, Client, DashboardStats } from './types';

const INVOICES_KEY = 'invoicely_invoices';
const CLIENTS_KEY = 'invoicely_clients';

// ─── Invoices ────────────────────────────────────────────────────────────────

export function getInvoices(): Invoice[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(INVOICES_KEY);
    return raw ? JSON.parse(raw) : getSeedInvoices();
  } catch {
    return [];
  }
}

export function saveInvoice(invoice: Invoice): void {
  const invoices = getInvoices();
  const idx = invoices.findIndex(i => i.id === invoice.id);
  if (idx >= 0) {
    invoices[idx] = invoice;
  } else {
    invoices.unshift(invoice);
  }
  localStorage.setItem(INVOICES_KEY, JSON.stringify(invoices));
}

export function deleteInvoice(id: string): void {
  const invoices = getInvoices().filter(i => i.id !== id);
  localStorage.setItem(INVOICES_KEY, JSON.stringify(invoices));
}

export function getInvoice(id: string): Invoice | undefined {
  return getInvoices().find(i => i.id === id);
}

// ─── Clients ─────────────────────────────────────────────────────────────────

export function getClients(): Client[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(CLIENTS_KEY);
    return raw ? JSON.parse(raw) : getSeedClients();
  } catch {
    return [];
  }
}

export function saveClient(client: Client): void {
  const clients = getClients();
  const idx = clients.findIndex(c => c.id === client.id);
  if (idx >= 0) {
    clients[idx] = client;
  } else {
    clients.unshift(client);
  }
  localStorage.setItem(CLIENTS_KEY, JSON.stringify(clients));
}

export function deleteClient(id: string): void {
  const clients = getClients().filter(c => c.id !== id);
  localStorage.setItem(CLIENTS_KEY, JSON.stringify(clients));
}

// ─── Stats ────────────────────────────────────────────────────────────────────

export function getDashboardStats(): DashboardStats {
  const invoices = getInvoices();
  const now = new Date();
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

  let totalRevenue = 0;
  let outstanding = 0;
  let overdue = 0;
  let paidThisMonth = 0;
  let paidInvoices = 0;
  let sentInvoices = 0;
  let overdueInvoices = 0;

  invoices.forEach(inv => {
    const total = calcTotal(inv);
    if (inv.status === 'paid') {
      totalRevenue += total;
      paidInvoices++;
      const updated = new Date(inv.updatedAt);
      if (updated >= startOfMonth) paidThisMonth += total;
    } else if (inv.status === 'sent') {
      outstanding += total;
      sentInvoices++;
      if (new Date(inv.dueDate) < now) {
        overdue += total;
        overdueInvoices++;
      }
    } else if (inv.status === 'overdue') {
      overdue += total;
      outstanding += total;
      overdueInvoices++;
    }
  });

  return {
    totalRevenue,
    outstanding,
    overdue,
    paidThisMonth,
    totalInvoices: invoices.length,
    paidInvoices,
    sentInvoices,
    overdueInvoices,
  };
}

export function calcSubtotal(inv: Invoice): number {
  return inv.lineItems.reduce((s, item) => s + item.quantity * item.rate, 0);
}

export function calcTax(inv: Invoice): number {
  return calcSubtotal(inv) * (inv.taxRate / 100);
}

export function calcTotal(inv: Invoice): number {
  return calcSubtotal(inv) + calcTax(inv);
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
  }).format(amount);
}

export function generateInvoiceNumber(): string {
  const invoices = getInvoices();
  const nums = invoices
    .map(i => parseInt(i.invoiceNumber.replace(/\D/g, ''), 10))
    .filter(n => !isNaN(n));
  const next = nums.length ? Math.max(...nums) + 1 : 1001;
  return `INV-${String(next).padStart(4, '0')}`;
}

// ─── Seed Data ────────────────────────────────────────────────────────────────

function getSeedClients(): Client[] {
  const clients: Client[] = [
    { id: 'c1', name: 'Sarah Mitchell', email: 'sarah@brightwave.io', company: 'BrightWave Studio', address: '123 Design Ave, San Francisco, CA 94103', phone: '+1 415 555 0101', createdAt: '2024-01-15T10:00:00Z' },
    { id: 'c2', name: 'James Okonkwo', email: 'james@vertextech.co', company: 'Vertex Technologies', address: '456 Tech Blvd, Austin, TX 78701', phone: '+1 512 555 0202', createdAt: '2024-02-01T10:00:00Z' },
    { id: 'c3', name: 'Priya Sharma', email: 'priya@lumencorp.com', company: 'Lumen Corp', address: '789 Commerce St, New York, NY 10001', phone: '+1 212 555 0303', createdAt: '2024-03-10T10:00:00Z' },
  ];
  localStorage.setItem(CLIENTS_KEY, JSON.stringify(clients));
  return clients;
}

function getSeedInvoices(): Invoice[] {
  const invoices: Invoice[] = [
    {
      id: 'inv1', invoiceNumber: 'INV-1001', clientId: 'c1', clientName: 'Sarah Mitchell',
      clientEmail: 'sarah@brightwave.io', clientCompany: 'BrightWave Studio',
      clientAddress: '123 Design Ave, San Francisco, CA 94103',
      status: 'paid', issueDate: '2024-12-01', dueDate: '2024-12-31',
      lineItems: [
        { id: 'li1', description: 'Brand Identity Design', quantity: 1, rate: 2500 },
        { id: 'li2', description: 'Logo Variations (5)', quantity: 5, rate: 300 },
      ],
      taxRate: 8, notes: 'Thank you for your business!',
      fromName: 'Alex Rivera', fromEmail: 'alex@freelance.io', fromCompany: 'Rivera Creative',
      fromAddress: '100 Maker St, Portland, OR 97201',
      createdAt: '2024-12-01T09:00:00Z', updatedAt: '2024-12-20T14:00:00Z',
    },
    {
      id: 'inv2', invoiceNumber: 'INV-1002', clientId: 'c2', clientName: 'James Okonkwo',
      clientEmail: 'james@vertextech.co', clientCompany: 'Vertex Technologies',
      clientAddress: '456 Tech Blvd, Austin, TX 78701',
      status: 'sent', issueDate: '2025-01-10', dueDate: '2025-02-10',
      lineItems: [
        { id: 'li3', description: 'Full-Stack Web Development', quantity: 40, rate: 150 },
        { id: 'li4', description: 'Deployment & DevOps Setup', quantity: 1, rate: 800 },
      ],
      taxRate: 0, notes: 'Payment due within 30 days.',
      fromName: 'Alex Rivera', fromEmail: 'alex@freelance.io', fromCompany: 'Rivera Creative',
      fromAddress: '100 Maker St, Portland, OR 97201',
      createdAt: '2025-01-10T09:00:00Z', updatedAt: '2025-01-10T09:00:00Z',
    },
    {
      id: 'inv3', invoiceNumber: 'INV-1003', clientId: 'c3', clientName: 'Priya Sharma',
      clientEmail: 'priya@lumencorp.com', clientCompany: 'Lumen Corp',
      clientAddress: '789 Commerce St, New York, NY 10001',
      status: 'overdue', issueDate: '2024-11-15', dueDate: '2024-12-15',
      lineItems: [
        { id: 'li5', description: 'UX Audit & Report', quantity: 1, rate: 1800 },
        { id: 'li6', description: 'Wireframe Prototypes', quantity: 3, rate: 600 },
      ],
      taxRate: 8.875,
      fromName: 'Alex Rivera', fromEmail: 'alex@freelance.io', fromCompany: 'Rivera Creative',
      fromAddress: '100 Maker St, Portland, OR 97201',
      createdAt: '2024-11-15T09:00:00Z', updatedAt: '2024-11-15T09:00:00Z',
    },
    {
      id: 'inv4', invoiceNumber: 'INV-1004', clientId: 'c1', clientName: 'Sarah Mitchell',
      clientEmail: 'sarah@brightwave.io', clientCompany: 'BrightWave Studio',
      clientAddress: '123 Design Ave, San Francisco, CA 94103',
      status: 'draft', issueDate: '2025-01-20', dueDate: '2025-02-20',
      lineItems: [
        { id: 'li7', description: 'Social Media Kit', quantity: 1, rate: 1200 },
      ],
      taxRate: 8,
      fromName: 'Alex Rivera', fromEmail: 'alex@freelance.io', fromCompany: 'Rivera Creative',
      fromAddress: '100 Maker St, Portland, OR 97201',
      createdAt: '2025-01-20T09:00:00Z', updatedAt: '2025-01-20T09:00:00Z',
    },
  ];
  localStorage.setItem(INVOICES_KEY, JSON.stringify(invoices));
  return invoices;
}
